import express from "express";
import fetch from "node-fetch";
const app = express();
app.use(express.static("public"));

const API_KEY = process.env.API_KEY || "YOUR_KEY_HERE"; 
const REGIONS = "eu,us,uk,au,za";
const MARKETS = "h2h";

async function fetchOdds() {
  const url = `https://api.the-odds-api.com/v4/sports/?apiKey=${API_KEY}`;
  const sports = await fetch(url).then(r => r.json());

  let matches = [];

  for (const s of sports) {
    try {
      const oddsURL = `https://api.the-odds-api.com/v4/sports/${s.key}/odds/?regions=${REGIONS}&markets=${MARKETS}&apiKey=${API_KEY}`;
      const o = await fetch(oddsURL).then(r => r.json());

      o.forEach(event => {
        if (!event.bookmakers) return;

        event.bookmakers.forEach(b1 => {
          event.bookmakers.forEach(b2 => {
            if (b1.key === b2.key) return;
            try {
              const h = b1.markets[0].outcomes.find(x => x.name === "Home");
              const a = b2.markets[0].outcomes.find(x => x.name === "Away");
              if (!h || !a) return;

              const implied = (1 / h.price) + (1 / a.price);
              const profit = (1 / implied - 1) * 100;
              if (profit > 0) {
                matches.push({
                  match: event.teams.join(" vs "),
                  profitPct: profit,
                  bookHome: `${b1.title} @ ${h.price}`,
                  bookAway: `${b2.title} @ ${a.price}`
                });
              }
            } catch {}
          });
        });
      });

    } catch {}
  }

  matches.sort((a,b) => b.profitPct - a.profitPct);
  return matches;
}

app.get("/api/scan", async (req,res) => {
  const results = await fetchOdds();
  res.json({ results });
});

app.listen(3000, () => {
  console.log("✅ Running on http://localhost:3000");
});